#define Version	"Spin Version 4.2.5 -- 2 April 2005"
